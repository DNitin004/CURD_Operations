package com.example.crud.operations.repository;




import org.springframework.data.jpa.repository.JpaRepository;

import com.example.crud.operations.model.Account;

public interface AccountRepository extends JpaRepository<Account, Long> {
}

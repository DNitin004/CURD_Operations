package com.example.crud.operations.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.crud.operations.model.Account;
import com.example.crud.operations.service.AccountService;

@Controller
public class BankController {

    private final AccountService service;

    public BankController(AccountService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("accounts", this.service.findAll());
        return "index";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("account", new Account());
        return "create";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute Account account) {
        this.service.save(account);
        return "redirect:/";
    }

    @GetMapping("/deposit/{id}")
    public String depositForm(@PathVariable Long id, Model model) {
        this.service.findById(id).ifPresent(account -> model.addAttribute("account", account));
        return "deposit";
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam Long id, @RequestParam double amount) {
        this.service.deposit(id, amount);
        return "redirect:/";
    }

    @GetMapping("/withdraw/{id}")
    public String withdrawForm(@PathVariable Long id, Model model) {
        this.service.findById(id).ifPresent(account -> model.addAttribute("account", account));
        return "withdraw";
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam Long id, @RequestParam double amount) {
        this.service.withdraw(id, amount);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        this.service.delete(id);
        return "redirect:/";
    }
}

package com.example.crud.operations.service;




import org.springframework.stereotype.Service;

import com.example.crud.operations.model.Account;
import com.example.crud.operations.repository.AccountRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    private final AccountRepository repository;

    public AccountService(AccountRepository repository) {
        this.repository = repository;
    }

    public List<Account> findAll() {
        return this.repository.findAll();
    }

    public Optional<Account> findById(Long id) {
        return this.repository.findById(id);
    }

    public Account save(Account account) {
        return this.repository.save(account);
    }

    public void delete(Long id) {
        this.repository.deleteById(id);
    }

    public void deposit(Long id, double amount) {
        this.repository.findById(id).ifPresent(account -> {
            account.setBalance(account.getBalance() + amount);
            this.repository.save(account);
        });
    }

    public void withdraw(Long id, double amount) {
        this.repository.findById(id).ifPresent(account -> {
            if (account.getBalance() >= amount) {
                account.setBalance(account.getBalance() - amount);
                this.repository.save(account);
            }
        });
    }
}
